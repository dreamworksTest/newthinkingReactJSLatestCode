import './App.css';
import React, { lazy, Suspense } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Loading from './components/Loading/Loading';
const Main  = lazy(() => import ('./components/Main/Main'));
const Footer = lazy(() => import("./components/Footer/Footer"));
const Header = lazy(() => import("./components/Header/Header"));
 
 

function App() {
  return (
    <div>
          <Suspense fallback={<Loading />}>
            <Header />
            <Main/>
            <Footer />
          </Suspense>
    </div>
  );
}

export default App;

// import React, { useEffect, useRef, useState } from 'react';
// import './Chatbot.css'; // Import your CSS file for styling
// import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// // ... (Your existing imports)

// const Chatbot = () => {
//   const [isChatOpen, setIsChatOpen] = useState(false);
//   const [inputMessage, setInputMessage] = useState('');
//   const { transcript, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();
//   const [chatMessages, setChatMessages] = useState([
//     { type: 'bot', text: 'Hello! How can I help you?' },
//   ]);
//   const [isMicOn, setIsMicOn] = useState(false);
//   const [isLoading, setIsLoading] = useState(false); // Added loading state
//   const chatbotBodyRef = useRef(null);

//   useEffect(() => {
//     // Scroll to the bottom of the chatbot-body
//     if (chatbotBodyRef.current) {
//       chatbotBodyRef.current.scrollTop = chatbotBodyRef.current.scrollHeight;
//     }
//   }, [chatMessages]);

//   const startListening = () => {
//     console.log('Starting speech recognition...');
//     SpeechRecognition.startListening({ continuous: true, language: 'en-IN' });
//   };

//   const toggleChat = () => {
//     setIsChatOpen((prevState) => !prevState);
//   };
 


//   const elevenLabs = (text) => {
//     setIsLoading(true); // Set loading to true when waiting for response
//     console.log('this is elevenlabs: ' + text);
//     fetch('https://api.elevenlabs.io/v1/text-to-speech/29vD33N1CtxCmqQRPOHJ/stream', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'xi-api-key': '30db19d4fc2dfc7942bce8f1ed0e2fda',
//       },
//       body: JSON.stringify({
//         "model_id": "eleven_multilingual_v2",
//         "text": text,
//         "voice_settings": {
//           "stability": 1,
//           "similarity_boost": 1.0,
//           "style": 1.0,
//           "use_speaker_boost": true
//         }
//       }),
//     })
//       .then((response) => {
//         if (!response.body) {
//           throw new Error('ReadableStream not supported!');
//         }
//         return response.body;
//       })
//       .then((stream) => {
//         // Play the audio in chunks
//         console.log("first time stram");
//         console.log(stream);
//         playStreamingAudio(stream);
//         // setChatMessages((prevMessages) => [
//         //   ...prevMessages.slice(0, -1), // Remove the loading indicator
//         //   { type: 'bot', text: holdMessage },
//         // ]);
//         // setIsLoading(false); // Set loading to false after starting to play
//       })
//       .catch((error) => {
//         setIsLoading(false); // Set loading to false in case of an error
//         console.error('Error calling API:', error);
//       }).finally(() => {
//         setChatMessages((prevMessages) => [
//           ...prevMessages.slice(0, -1), // Remove the loading indicator
//           { type: 'bot', text: text },
//         ]);
//         setIsLoading(false); // Set loading to false after starting to play
//       });
//   };
  
  
  

  
  
//   const playStreamingAudio = async (stream) => {
//     const audio = new Audio();
//     const mediaSource = new MediaSource();
//     audio.src = URL.createObjectURL(mediaSource);
  
//     let sourceBuffer;
//     let bufferQueue = [];
//     let isAppending = false;
  
//     const chunkSize = 5; // Set your desired smaller chunk size
  
//     mediaSource.addEventListener('sourceopen', () => {
//       sourceBuffer = mediaSource.addSourceBuffer('audio/mpeg');
//       sourceBuffer.mode = 'sequence';
  
//       const reader = stream.getReader();
  
//       const readChunk = async () => {
//         const { value, done } = await reader.read();
  
//         if (done) {
//           // Wait for the source buffer to finish updating before calling endOfStream
//           if (!sourceBuffer.updating) {
//             mediaSource.endOfStream();
//           } else {
//             // If the source buffer is still updating, wait for 'updateend' event
//             sourceBuffer.addEventListener('updateend', () => {
//               mediaSource.endOfStream();
//             });
//           }
//           return;
//         }
  
//         console.log('Read chunk:', value);
  
//         bufferQueue.push(value);
  
//         if (!isAppending && !sourceBuffer.updating) {
//           console.log('Appending chunk');
//           appendNextChunk();
//         }
  
//         readChunk();
//       };
  
//       const appendNextChunk = async () => {
//         if (bufferQueue.length > 0) {
//           isAppending = true;
//           sourceBuffer.appendBuffer(bufferQueue.shift());
//         }
//       };
  
//       sourceBuffer.addEventListener('updateend', () => {
//         isAppending = false;
//         console.log('Update end');
//         appendNextChunk(); // Continue appending chunks
//       });
  
//       readChunk();
     
//     });
  
//     mediaSource.addEventListener('sourceended', () => {
//       console.log('MediaSource has ended');
//     });
  
//     mediaSource.addEventListener('sourceclose', () => {
//       console.log('MediaSource is closed');
//     });
  
//     audio.play();
   
//   };
  
  
  
  

//   const handleMicButtonClick = () => {
//     console.log('Mic button clicked');
//     setInputMessage(''); 
//     const messageToSendFromAudio = '';
//     resetTranscript();
    
//     if (!isMicOn) {
//       // If mic is off, start listening
//       console.log('Starting speech recognition...');
//       SpeechRecognition.startListening({ continuous: true, language: 'en-IN' });
//     } else {
//       // If mic is on, stop listening
//       console.log('Stopping speech recognition...');
//       SpeechRecognition.stopListening();

//       // Append the transcribed text to chatMessages
//       const messageToSendFromAudio = transcript.trim();
//       if (messageToSendFromAudio) {
//         setChatMessages((prevMessages) => [
//           ...prevMessages,
//           { type: 'user', text: messageToSendFromAudio },
//         ]);

        
//         // Call the API here
//         fetch('https://api.mirar.ai/auth/getAIResponse', {
//           method: 'POST',
//           headers: {
//             'Content-Type': 'application/json',
//             'x-api-key': '42bef730-7a95-475e-990f-ec4e3d450b24',
//           },
//           body: JSON.stringify({
//             message: messageToSendFromAudio,
//           }),
//         })
//           .then((response) => response.json())
//           .then((data) => {
//             console.log('API Response:', data);
//             setChatMessages((prevMessages) => [
//               ...prevMessages,
//               { type: 'bot', text: '...' }, // Loading indicator for the last bot message
//             ]);

//             elevenLabs(data.text);

            
//             // Append the bot message to the chatMessages state
           
//           })
//           .catch((error) => {
//             console.error('Error calling API:', error);
//           });

//         // Reset the transcript after sending the message
//         resetTranscript();
//       }
//     }

//     // Toggle mic status
//     setIsMicOn((prevMicStatus) => !prevMicStatus);
//   };

//   const handleSendMessage = () => {
//     const messageToSend = inputMessage.trim();

//     if (!messageToSend) {
//       return;
//     }

//     // Append the user message to the chatMessages state
//     setChatMessages((prevMessages) => [
//       ...prevMessages,
//       { type: 'user', text: messageToSend },
//     ]);

//     // Clear the input field
//     setInputMessage('');

//     // Call the API here
//     fetch('https://api.mirar.ai/auth/getAIResponse', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'x-api-key': '42bef730-7a95-475e-990f-ec4e3d450b24',
//       },
//       body: JSON.stringify({
//         message: messageToSend,
//       }),
//     })
//       .then((response) => response.json())
//       .then((data) => {
//         console.log('API Response:', data);
//         // Append the bot message to the chatMessages state
//         setChatMessages((prevMessages) => [
//           ...prevMessages,
//           { type: 'bot', text: '...' }, // Loading indicator for the last bot message
//         ]);
  
//         elevenLabs(data.text);
      
//         // Simulate delay (replace with actual API response delay)
//         // setTimeout(() => {
//         //   // Replace the loading indicator with the actual response
//         //   setChatMessages((prevMessages) => [
//         //     ...prevMessages.slice(0, -1), // Remove the loading indicator
//         //     { type: 'bot', text: data.text },
//         //   ]);
//         // }, 1000); // Adjust the delay as needed
//       })
//       .catch((error) => {
//         console.error('Error calling API:', error);
//       });
//   };

//   const handleInputKeyPress = (event) => {
//     if (event.key === 'Enter') {
//       // If the user presses Enter, send the message
//       handleSendMessage();
//     }
//   };

//   useEffect(() => {
//     // You may want to add additional logic here if needed
//   }, []);

//   return (
   
//     <div className={`chatbot-container ${isChatOpen ? 'open' : ''}`}>
//     <div className="chatbot-toggle" onClick={toggleChat}>
//         <img src="../assets/img/chatBot/message.png" className='chatbottoggelimage' alt="Chatbot Icon" />
//       </div>
//       {isChatOpen && (
//         <div className="chatbot-window">
//           <div className="chatbot-header">
//             <span className="chatbot-title">Support</span>
//             <button className='closeButton chatbotButton' onClick={toggleChat}>Close</button>
//           </div>
//           <div className="chatbot-body" ref={chatbotBodyRef}>
//             {/* Display chat messages */}
//             {chatMessages.map((message, index) => (
//               <div key={index} className={`chat-message ${message.type}`}>
//                 {message.type === 'bot' && message.text === '...' && 'Loading...'}
//                 {message.type === 'bot' && message.text !== '...' && message.text}
//                 {message.type !== 'bot' && message.text}
//               </div>
//             ))}
//           </div>
//           {/* Input field and send button */}
//           <div className="chat-input">
//             <input
//               type="text"
//               placeholder="Type your message..."
//               value={inputMessage}
//               onChange={(e) => setInputMessage(e.target.value)}
//               onKeyPress={handleInputKeyPress}
//             />
//             <button className="send-button chatbotButton" onClick={handleSendMessage}>
//               <img src="../assets/img/chatBot/send.png" alt="Send Message" />
//             </button>
//             {browserSupportsSpeechRecognition && (
//               <button className="mic-button chatbotButton" onClick={handleMicButtonClick}>
//                 <img src={`../assets/img/chatBot/${isMicOn ? 'stop' : 'microphone'}.png`} alt="Mic Icon" />
//               </button>
//             )}
//           </div>
//          {/* {isLoading && <div>Loading...</div>} */} 
//         </div>
//       )}
//     </div>
//   );
// };

// export default Chatbot;

// old code 2 
// import React, { useEffect, useRef, useState } from 'react';
// import './Chatbot.css'; // Import your CSS file for styling
// import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// // ... (Your existing imports)

// const Chatbot = () => {
  
//   const [isChatOpen, setIsChatOpen] = useState(false);
//   const [inputMessage, setInputMessage] = useState('');
//   const { transcript, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();
//   const [chatMessages, setChatMessages] = useState([
//     { type: 'bot', text: 'Hello! How can I help you?' },
//   ]);
//   const [isMicOn, setIsMicOn] = useState(false);
//   const [isLoading, setIsLoading] = useState(false); // Added loading state
//   const chatbotBodyRef = useRef(null);

//   useEffect(() => {
//     // Scroll to the bottom of the chatbot-body
//     if (chatbotBodyRef.current) {
//       chatbotBodyRef.current.scrollTop = chatbotBodyRef.current.scrollHeight;
//     }
//   }, [chatMessages]);

//   const startListening = () => {
//     console.log('Starting speech recognition...');
//     SpeechRecognition.startListening({ continuous: true, language: 'en-IN' });
//   };

//   const toggleChat = () => {
//     setIsChatOpen((prevState) => !prevState);
//   };

  

//   const elevenLabs = (text) => {
//     setIsLoading(true); // Set loading to true when waiting for response
//     console.log('this is elevenlabs: ' + text);
//     fetch('https://api.elevenlabs.io/v1/text-to-speech/29vD33N1CtxCmqQRPOHJ/stream', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'xi-api-key': '30db19d4fc2dfc7942bce8f1ed0e2fda',
//       },
//       body: JSON.stringify({
//         "model_id": "eleven_multilingual_v2",
//         "text": text,
//         "voice_settings": {
//           "stability": 1,
//           "similarity_boost": 1.0,
//           "style": 1.0,
//           "use_speaker_boost": true
//         }
//       }),
//     })
//       .then((response) => {
//         if (!response.body) {
//           throw new Error('ReadableStream not supported!');
//         }
//         return response.body;
//       })
//       .then((stream) => {
//         // Play the audio in chunks
//         console.log("first time stram");
//         console.log(stream);
//         playStreamingAudio(stream);
//         setIsLoading(false); // Set loading to false after starting to play
//       })
//       .catch((error) => {
//         setIsLoading(false); // Set loading to false in case of an error
//         console.error('Error calling API:', error);
//       });
//   };
  
  
  
  
  
//   const playStreamingAudio = async (stream) => {
//     const audio = new Audio();
//     const mediaSource = new MediaSource();
//     audio.src = URL.createObjectURL(mediaSource);
  
//     let sourceBuffer;
//     let bufferQueue = [];
//     let isAppending = false;
  
//     const chunkSize = 5; // Set your desired smaller chunk size
  
//     mediaSource.addEventListener('sourceopen', () => {
//       sourceBuffer = mediaSource.addSourceBuffer('audio/mpeg');
//       sourceBuffer.mode = 'sequence';
  
//       const reader = stream.getReader();
  
//       const readChunk = async () => {
//         const { value, done } = await reader.read();
  
//         if (done) {
//           // Wait for the source buffer to finish updating before calling endOfStream
//           if (!sourceBuffer.updating) {
//             mediaSource.endOfStream();
//           } else {
//             // If the source buffer is still updating, wait for 'updateend' event
//             sourceBuffer.addEventListener('updateend', () => {
//               mediaSource.endOfStream();
//             });
//           }
//           return;
//         }
  
//         console.log('Read chunk:', value);
  
//         bufferQueue.push(value);
  
//         if (!isAppending && !sourceBuffer.updating) {
//           console.log('Appending chunk');
//           appendNextChunk();
//         }
  
//         readChunk();
//       };
  
//       const appendNextChunk = async () => {
//         if (bufferQueue.length > 0) {
//           isAppending = true;
//           sourceBuffer.appendBuffer(bufferQueue.shift());
//         }
//       };
  
//       sourceBuffer.addEventListener('updateend', () => {
//         isAppending = false;
//         console.log('Update end');
//         appendNextChunk(); // Continue appending chunks
//       });
  
//       readChunk();
//     });
  
//     mediaSource.addEventListener('sourceended', () => {
//       console.log('MediaSource has ended');
//     });
  
//     mediaSource.addEventListener('sourceclose', () => {
//       console.log('MediaSource is closed');
//     });
  
//     audio.play();
//   };
  
  
  
  

//   const handleMicButtonClick = () => {
//     console.log('Mic button clicked');
//     setInputMessage(''); 
//     const messageToSendFromAudio = '';
//     resetTranscript();
    
//     if (!isMicOn) {
//       // If mic is off, start listening
//       console.log('Starting speech recognition...');
//       SpeechRecognition.startListening({ continuous: true, language: 'en-IN' });
//     } else {
//       // If mic is on, stop listening
//       console.log('Stopping speech recognition...');
//       SpeechRecognition.stopListening();

//       // Append the transcribed text to chatMessages
//       const messageToSendFromAudio = transcript.trim();
//       if (messageToSendFromAudio) {
//         setChatMessages((prevMessages) => [
//           ...prevMessages,
//           { type: 'user', text: messageToSendFromAudio },
//         ]);

        
//         // Call the API here
//         fetch('https://api.mirar.ai/auth/getAIResponse', {
//           method: 'POST',
//           headers: {
//             'Content-Type': 'application/json',
//             'x-api-key': '42bef730-7a95-475e-990f-ec4e3d450b24',
//           },
//           body: JSON.stringify({
//             message: messageToSendFromAudio,
//           }),
//         })
//           .then((response) => response.json())
//           .then((data) => {
//             console.log('API Response:', data);
//             elevenLabs(data.text);
//             // Append the bot message to the chatMessages state
//             setChatMessages((prevMessages) => [
//               ...prevMessages,
//               { type: 'bot', text: data.text },
//             ]);
//           })
//           .catch((error) => {
//             console.error('Error calling API:', error);
//           });

//         // Reset the transcript after sending the message
//         resetTranscript();
//       }
//     }

//     // Toggle mic status
//     setIsMicOn((prevMicStatus) => !prevMicStatus);
//   };

//   const handleSendMessage = () => {
//     const messageToSend = inputMessage.trim();

//     if (!messageToSend) {
//       return;
//     }

//     // Append the user message to the chatMessages state
//     setChatMessages((prevMessages) => [
//       ...prevMessages,
//       { type: 'user', text: messageToSend },
//     ]);

//     // Clear the input field
//     setInputMessage('');

//     // Call the API here
//     fetch('https://api.mirar.ai/auth/getAIResponse', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'x-api-key': '42bef730-7a95-475e-990f-ec4e3d450b24',
//       },
//       body: JSON.stringify({
//         message: messageToSend,
//       }),
//     })
//       .then((response) => response.json())
//       .then((data) => {
//         console.log('API Response:', data);

//         // Append the bot message to the chatMessages state
//         setChatMessages((prevMessages) => [
//           ...prevMessages,
//           { type: 'bot', text: '...' }, // Loading indicator for the last bot message
//         ]);

//         elevenLabs(data.text);
//         // Simulate delay (replace with actual API response delay)
//         setTimeout(() => {
//           // Replace the loading indicator with the actual response
//           setChatMessages((prevMessages) => [
//             ...prevMessages.slice(0, -1), // Remove the loading indicator
//             { type: 'bot', text: data.text },
//           ]);
//         }, 1000); // Adjust the delay as needed
//       })
//       .catch((error) => {
//         console.error('Error calling API:', error);
//       });
//   };

//   const handleInputKeyPress = (event) => {
//     if (event.key === 'Enter') {
//       // If the user presses Enter, send the message
//       handleSendMessage();
//     }
//   };

//   useEffect(() => {
//     // You may want to add additional logic here if needed
//   }, []);

//   return (

//     <div className={`chatbot-container ${isChatOpen ? 'open' : ''}`}>
//     <div className="chatbot-toggle" onClick={toggleChat}>
//         <img src="../assets/img/chatBot/message.png" className='chatbottoggelimage' alt="Chatbot Icon" />
//       </div>
//       {isChatOpen && (
//         <div className="chatbot-window">
//           <div className="chatbot-header">
//             <span className="chatbot-title">Support</span>
//             <button className='closeButton chatbotButton' onClick={toggleChat}>Close</button>
//           </div>
//           <div className="chatbot-body" ref={chatbotBodyRef}>
//             {/* Display chat messages */}
//             {chatMessages.map((message, index) => (
//               <div key={index} className={`chat-message ${message.type}`}>
//                 {message.type === 'bot' && message.text === '...' && 'Loading...'}
//                 {message.type === 'bot' && message.text !== '...' && message.text}
//                 {message.type !== 'bot' && message.text}
//               </div>
//             ))}
//           </div>
//           {/* Input field and send button */}
//           <div className="chat-input">
//             <input
//               type="text"
//               placeholder="Type your message..."
//               value={inputMessage}
//               onChange={(e) => setInputMessage(e.target.value)}
//               onKeyPress={handleInputKeyPress}
//             />
//             <button className="send-button chatbotButton" onClick={handleSendMessage}>
//               <img src="../assets/img/chatBot/send.png" alt="Send Message" />
//             </button>
//             {browserSupportsSpeechRecognition && (
//               <button className="mic-button chatbotButton" onClick={handleMicButtonClick}>
//                 <img src={`../assets/img/chatBot/${isMicOn ? 'stop' : 'microphone'}.png`} alt="Mic Icon" />
//               </button>
//             )}
//           </div>
//           {isLoading && <div>Loading...</div>} {/* Show loading indicator */}
//         </div>
//       )}
//     </div>
//   );
// };

// export default Chatbot;

// live working code
import React, { useEffect, useRef, useState } from 'react';
import './Chatbot.css'; // Import your CSS file for styling
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// ... (Your existing imports)

const Chatbot = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const { transcript, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();
  const [chatMessages, setChatMessages] = useState([
    { type: 'bot', text: 'Hello! How can I help you?' },
  ]);
  const [isMicOn, setIsMicOn] = useState(false);
  const [isLoading, setIsLoading] = useState(false); // Added loading state
  const chatbotBodyRef = useRef(null);

  useEffect(() => {
    // Scroll to the bottom of the chatbot-body
    if (chatbotBodyRef.current) {
      chatbotBodyRef.current.scrollTop = chatbotBodyRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const startListening = () => {
    console.log('Starting speech recognition...');
    SpeechRecognition.startListening({ continuous: true, language: 'en-IN' });
  };

  const toggleChat = () => {
    setIsChatOpen((prevState) => !prevState);
  };
 


  const elevenLabs = (text) => {
    setIsLoading(true); // Set loading to true when waiting for response
    console.log('this is elevenlabs: ' + text);
    fetch('https://api.elevenlabs.io/v1/text-to-speech/29vD33N1CtxCmqQRPOHJ/stream', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': '30db19d4fc2dfc7942bce8f1ed0e2fda',
      },
      body: JSON.stringify({
        "model_id": "eleven_multilingual_v2",
        "text": text,
        "voice_settings": {
          "stability": 1,
          "similarity_boost": 1.0,
          "style": 1.0,
          "use_speaker_boost": true
        }
      }),
    })
      .then((response) => {
        if (!response.body) {
          throw new Error('ReadableStream not supported!');
        }
        return response.body;
      })
      .then((stream) => {
        // Play the audio in chunks
        console.log("first time stram");
        console.log(stream);
        playStreamingAudio(stream);
        // setChatMessages((prevMessages) => [
        //   ...prevMessages.slice(0, -1), // Remove the loading indicator
        //   { type: 'bot', text: holdMessage },
        // ]);
        // setIsLoading(false); // Set loading to false after starting to play
      })
      .catch((error) => {
        setIsLoading(false); // Set loading to false in case of an error
        console.error('Error calling API:', error);
      }).finally(() => {
        setChatMessages((prevMessages) => [
          ...prevMessages.slice(0, -1), // Remove the loading indicator
          { type: 'bot', text: text },
        ]);
        setIsLoading(false); // Set loading to false after starting to play
      });
  };
  
  
  

  
  
  const playStreamingAudio = async (stream) => {
    const audio = new Audio();
    const mediaSource = new MediaSource();
    audio.src = URL.createObjectURL(mediaSource);
  
    let sourceBuffer;
    let bufferQueue = [];
    let isAppending = false;
  
    const chunkSize = 5; // Set your desired smaller chunk size
  
    mediaSource.addEventListener('sourceopen', () => {
      sourceBuffer = mediaSource.addSourceBuffer('audio/mpeg');
      sourceBuffer.mode = 'sequence';
  
      const reader = stream.getReader();
  
      const readChunk = async () => {
        const { value, done } = await reader.read();
  
        if (done) {
          // Wait for the source buffer to finish updating before calling endOfStream
          if (!sourceBuffer.updating) {
            mediaSource.endOfStream();
          } else {
            // If the source buffer is still updating, wait for 'updateend' event
            sourceBuffer.addEventListener('updateend', () => {
              mediaSource.endOfStream();
            });
          }
          return;
        }
  
        console.log('Read chunk:', value);
  
        bufferQueue.push(value);
  
        if (!isAppending && !sourceBuffer.updating) {
          console.log('Appending chunk');
          appendNextChunk();
        }
  
        readChunk();
      };
  
      const appendNextChunk = async () => {
        if (bufferQueue.length > 0) {
          isAppending = true;
          sourceBuffer.appendBuffer(bufferQueue.shift());
        }
      };
  
      sourceBuffer.addEventListener('updateend', () => {
        isAppending = false;
        console.log('Update end');
        appendNextChunk(); // Continue appending chunks
      });
  
      readChunk();
     
    });
  
    mediaSource.addEventListener('sourceended', () => {
      console.log('MediaSource has ended');
    });
  
    mediaSource.addEventListener('sourceclose', () => {
      console.log('MediaSource is closed');
    });
  
    audio.play();
   
  };
  
  
  
  

  const handleMicButtonClick = () => {
    console.log('Mic button clicked');
    setInputMessage(''); 
    const messageToSendFromAudio = '';
    resetTranscript();
    
    if (!isMicOn) {
      // If mic is off, start listening
      console.log('Starting speech recognition...');
      SpeechRecognition.startListening({ continuous: true, language: 'en-IN' });
    } else {
      // If mic is on, stop listening
      console.log('Stopping speech recognition...');
      SpeechRecognition.stopListening();

      // Append the transcribed text to chatMessages
      const messageToSendFromAudio = transcript.trim();
      if (messageToSendFromAudio) {
        setChatMessages((prevMessages) => [
          ...prevMessages,
          { type: 'user', text: messageToSendFromAudio },
        ]);

        
        // Call the API here
        fetch('https://api.mirar.ai/auth/getAIResponse', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': '42bef730-7a95-475e-990f-ec4e3d450b24',
          },
          body: JSON.stringify({
            message: messageToSendFromAudio,
          }),
        })
          .then((response) => response.json())
          .then((data) => {
            console.log('API Response:', data);
            setChatMessages((prevMessages) => [
              ...prevMessages,
              { type: 'bot', text: '...' }, // Loading indicator for the last bot message
            ]);

            elevenLabs(data.text);

            
            // Append the bot message to the chatMessages state
           
          })
          .catch((error) => {
            console.error('Error calling API:', error);
          });

        // Reset the transcript after sending the message
        resetTranscript();
      }
    }

    // Toggle mic status
    setIsMicOn((prevMicStatus) => !prevMicStatus);
  };

  const handleSendMessage = () => {
    const messageToSend = inputMessage.trim();

    if (!messageToSend) {
      return;
    }

    // Append the user message to the chatMessages state
    setChatMessages((prevMessages) => [
      ...prevMessages,
      { type: 'user', text: messageToSend },
    ]);

    // Clear the input field
    setInputMessage('');

    // Call the API here
    fetch('https://api.mirar.ai/auth/getAIResponse', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': '42bef730-7a95-475e-990f-ec4e3d450b24',
      },
      body: JSON.stringify({
        message: messageToSend,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('API Response:', data);
        // Append the bot message to the chatMessages state
        setChatMessages((prevMessages) => [
          ...prevMessages,
          { type: 'bot', text: '...' }, // Loading indicator for the last bot message
        ]);
  
        elevenLabs(data.text);
      
        // Simulate delay (replace with actual API response delay)
        // setTimeout(() => {
        //   // Replace the loading indicator with the actual response
        //   setChatMessages((prevMessages) => [
        //     ...prevMessages.slice(0, -1), // Remove the loading indicator
        //     { type: 'bot', text: data.text },
        //   ]);
        // }, 1000); // Adjust the delay as needed
      })
      .catch((error) => {
        console.error('Error calling API:', error);
      });
  };

  const handleInputKeyPress = (event) => {
    if (event.key === 'Enter') {
      // If the user presses Enter, send the message
      handleSendMessage();
    }
  };

  useEffect(() => {
    // You may want to add additional logic here if needed
  }, []);

  return (
    // <div className={`chatbot-container ${isChatOpen ? 'open' : ''}`}>
    // <div className="chatbot-toggle" onClick={toggleChat}>
    //     <img src="../assets/img/chatBot/message.png" className='chatbottoggelimage' alt="Chatbot Icon" />
    //   </div>
    //   {isChatOpen && (
    //     <div className="chatbot-window">
    //       <div className="chatbot-header">
    //         <span className="chatbot-title">Support</span>
    //         <button className='closeButton chatbotButton' onClick={toggleChat}>Close</button>
    //       </div>
    //       <div className="chatbot-body" ref={chatbotBodyRef}>
    //         {/* Display chat messages */}
    //         {chatMessages.map((message, index) => (
    //           <div key={index} className={`chat-message ${message.type}`}>
    //             {message.type === 'bot' && message.text === '...' && 'Loading...'}
    //             {message.type === 'bot' && message.text !== '...' && message.text}
    //             {message.type !== 'bot' && message.text}
    //           </div>
    //         ))}
    //       </div>
    //       {/* Input field and send button */}
    //       <div className="chat-input">
    //         <input
    //           type="text"
    //           placeholder="Type your message..."
    //           value={inputMessage}
    //           onChange={(e) => setInputMessage(e.target.value)}
    //           onKeyPress={handleInputKeyPress}
    //         />
    //         <button className="send-button chatbotButton" onClick={handleSendMessage}>
    //           <img src="../assets/img/chatBot/send.png" alt="Send Message" />
    //         </button>
    //         {browserSupportsSpeechRecognition && (
    //           <button className="mic-button chatbotButton" onClick={handleMicButtonClick}>
    //             <img src={`../assets/img/chatBot/${isMicOn ? 'stop' : 'microphone'}.png`} alt="Mic Icon" />
    //           </button>
    //         )}
    //       </div>
    //     </div>
    //   )}
    // </div>
    <div className={`chatbot-container ${isChatOpen ? 'open' : ''}`}>
    <div className="chatbot-toggle" onClick={toggleChat}>
        <img src="../assets/img/chatBot/message.png" className='chatbottoggelimage' alt="Chatbot Icon" />
      </div>
      {isChatOpen && (
        <div className="chatbot-window">
          <div className="chatbot-header">
            <span className="chatbot-title">Support</span>
            <button className='closeButton chatbotButton' onClick={toggleChat}>Close</button>
          </div>
          <div className="chatbot-body" ref={chatbotBodyRef}>
            {/* Display chat messages */}
            {chatMessages.map((message, index) => (
              <div key={index} className={`chat-message ${message.type}`}>
                {message.type === 'bot' && message.text === '...' && 'Loading...'}
                {message.type === 'bot' && message.text !== '...' && message.text}
                {message.type !== 'bot' && message.text}
              </div>
            ))}
          </div>
          {/* Input field and send button */}
          <div className="chat-input">
            <input
              type="text"
              placeholder="Type your message..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleInputKeyPress}
            />
            <button className="send-button chatbotButton" onClick={handleSendMessage}>
              <img src="../assets/img/chatBot/send.png" alt="Send Message" />
            </button>
            {browserSupportsSpeechRecognition && (
              <button className="mic-button chatbotButton" onClick={handleMicButtonClick}>
                <img src={`../assets/img/chatBot/${isMicOn ? 'stop' : 'microphone'}.png`} alt="Mic Icon" />
              </button>
            )}
          </div>
         {/* {isLoading && <div>Loading...</div>} */} 
        </div>
      )}
    </div>
  );
};

export default Chatbot;
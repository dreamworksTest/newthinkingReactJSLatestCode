import React, { useState } from 'react'
import { Link } from "react-router-dom";
import OwlCarousel from "react-owl-carousel";
import './Main.css';
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import ContactModal from '../ContactModal/contactModal';
// import Button from 'react-bootstrap/Button';
// import Modal from 'react-bootstrap/Modal';
// import MyVerticallyCenteredModal from "./contactModal";

const Main = () => {
  const [modalShow, setModalShow] = React.useState(false);

  
    const [showVideo, setShowVideo] = useState(false);
  
    const playVideo = () => {
      setShowVideo(true);
    };
  return (
    <>
      <div id='services' className="container-fluid bg-image mainSection">
        <div className="container">
          <div className="row">
            <div className="col-md-6 d-none d-md-block">
              <div
                className="d-flex align-items-center"
                style={{ height: "100vh" }}
              >
                <img
                  src="../assets/img/mainSection/coverimage.png"
                  alt="Avtar"
                  width="650"
                  height="650"
                  className="img-fluid"
                />
              </div>
            </div>
            <div className="col-md-6 text-center d-none d-md-block">
              <div
                className="d-flex align-items-center"
                style={{ height: "100vh" }}
              >
                <h3 className="text-sm text-md text-lg plexFont">
                  From Start-Up to Scale-Up: <br /> Unlock Growth with AI <br />
                  and Web3 Technologies
                </h3>
              </div>
            </div>
            <div className="col-12 d-block d-md-none" style={{ paddingTop: "50px" }}>
              <div className="d-flex align-items-center mainSectionMobileText">
                <h3 className="text-sm text-md text-lg plexFont ">
                  From Start-Up to Scale-Up: <br /> Unlock Growth with AI <br />
                  and Web3 Technologies
                </h3>
              </div>
              <img
                src="../assets/img/mainSection/coverimage.png"
                alt="Avtar"
                width="650"
                height="650"
                className="img-fluid"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="container-xxl py-5 DevelopmentSection">
        <div className="container">
          <div
            className="text-center mx-auto mb-5 wow fadeInUp"
            data-wow-delay="0.1s"
          >
            <br/>
            <h3 className="text-sm text-md text-lg plexFont">
              Development | Strategy | Implementation & Optimization
            </h3>
            <br/>
            <br/>

            <p className="text-sm text-md text-lg d-inline-block  border border-2 rounded-pill py-1 px-4 discoverNewThinkingAi publicSans hoverOnMe">
              Discover the New Thinking AI difference
            </p>
          </div>
        </div>
      </div>

      <div className="container-fluid  py-5 smallStepSection d-none d-md-block">
        <div className="container">
          <div
            className="text-center mx-auto mb-5 wow fadeInUp"
            data-wow-delay="0.1s"
          >
            <p className="text-sm text-md text-lg bussinessSoarText plexFont">
              From Small Steps to Giant Leaps <br /> We Make Businesses Soar
            </p>
          </div>
          <div className="row">
            <div className="col-md-4">
              <div className="box">
                <img
                  src="../assets/img/smallStepSection/Group_1.png"
                  alt="CustomerInteractions"
                />
                <h3 className="publicSans">1.3M+</h3>
                <p className="publicSans">
                  Customer Interactions <br />
                  through Conversational AI
                </p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="box">
                <img
                  src="../assets/img/smallStepSection/Group_2.png"
                  alt="Revenue"
                />
                <h3 className="publicSans">$10+ Million</h3>
                <p className="publicSans">
                  p/a in Revenue Generated <br />
                  through Our Tools
                </p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="box">
                <img
                  src="../assets/img/smallStepSection/Group_3.png"
                  alt="Businesses"
                />
                <h3 className="publicSans">20+</h3>
                <p className="publicSans">
                  Businesses across 6 APAC <br />
                  Locations Empowered
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container-fluid  py-5 smallStepSection smallStepMobileSection d-block d-md-none">
        <div className="container">
          <div
            className="text-center mx-auto mb-5 wow fadeInUp"
            data-wow-delay="0.1s"
          >
            <p className="text-sm text-md text-lg bussinessSoarText plexFont">
              From Small Steps to Giant Leaps <br /> We Make Businesses <br />
              Soar
            </p>
          </div>
          <div className="row">
            {/* <div className="owl-carousel smallStepCarousel "></div> */}

            <OwlCarousel
              className="smallStepCarousel"
              items={1}
              loop={true}
              autoplay={true}
              nav={true}
            >
              <div className="item">
                <div className="col-md-4">
                  <div className="box">
                    <div className="mainImageBox d-flex  justify-content-center align-items-center">
                      <img
                        src="../assets/img/smallStepSection/Group_1.png"
                        alt="CustomerInteractions"
                      />
                    </div>
                    <h3 className="publicSans">1.3M+</h3>
                    <p className="publicSans">
                      Customer Interactions <br />
                      through Conversational AI
                    </p>
                  </div>
                </div>
              </div>
              <div className="item">
                <div className="col-md-4">
                  <div className="box">
                    <div className="mainImageBox d-flex  justify-content-center align-items-center">
                      <img
                        src="../assets/img/smallStepSection/Group_2.png"
                        alt="Revenue"
                      />
                    </div>
                    <h3 className="publicSans">$10+ Million</h3>
                    <p className="publicSans">
                      p/a in Revenue Generated <br />
                      through Our Tools
                    </p>
                  </div>
                </div>
              </div>
              <div className="item">
                <div className="col-md-4">
                  <div className="box">
                    <div className="mainImageBox d-flex  justify-content-center align-items-center">
                      <img
                        src="../assets/img/smallStepSection/Group_3.png"
                        alt="Businesses"
                      />
                    </div>
                    <h3 className="publicSans">20+</h3>
                    <p className="publicSans">
                      Businesses across 6 APAC <br />
                      Locations Empowered
                    </p>
                  </div>
                </div>
              </div>
            </OwlCarousel>
          </div>
        </div>
      </div>
     
      <div
        className="container-fluid py-5 cathayPacificSection wow fadeInUp"
        data-wow-delay="0.1s"
      >
        <div className="container">
          <div className="row justify-content-center gy-5 m-2">
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/image1.png"
                alt="cathayPacific"
                className="img-fluid"
              />
            </div>
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/image2.png"
                alt="virgin"
                className="img-fluid"
              />
            </div>

            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/image3.png"
                alt="vive"
                className="img-fluid"
              />
            </div>
<div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/image4.png"
                alt="city"
                className="img-fluid"
              />
            </div>
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/image5.png"
                alt="swire"
                className="img-fluid"
              />
            </div>
           
          </div>
          <div className="row justify-content-center gy-5 m-2">
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/Image6.png"
                alt="learnfi"
                className="img-fluid"
              />
            </div>
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/Image7.png"
                alt="oh"
                className="img-fluid"
              />
            </div>
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/Image8.png"
                alt="wheeltec"
                className="img-fluid"
              />
            </div>
            <div className="col-md-2 col-6 d-flex justify-content-center align-items-center cathycolumn">
              <img
                src="../assets/img/cathySection/image9.png"
                alt="morph"
                className="img-fluid"
              />
</div>

          </div>
        </div>
      </div>

      <div
        className="container-fluid  py-5 videoSection wow fadeInUp"
        data-wow-delay="0.1s"
      >
        <div className="container">
          <p className="plexFont mainvideotext">
            With 30+ Years of Combined Expertise, <br /> we’ve fine-tuned
            solutions for businesses <br />
            big and small.
          </p>
          <br/>

          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="video-container">
        
<div className="embed-responsive embed-responsive-16by9">
      {showVideo ? (
        <iframe
          src="https://www.youtube.com/embed/D0UnqGm_miA?si=Nug7gdgUfXY7xXiu"
          title="YouTube video player"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        ></iframe>
      ) : (
        <>
          <img
            className="custom-poster-image"
            src="../assets/img/videoSection/poster.png"
            alt="Custom Poster"
          />

          <img
            className="custom-play-button"
            src="../assets/img/videoSection/play.png"
            alt="Play Video"
            onClick={playVideo}
          />
        </>
      )}
    </div>
                </div>
              </div>
            </div>
          </div>

          <br/>
          <br/>

          <p className="text-sm text-md text-lg d-inline-block  border border-2 rounded-pill py-1 px-4 discoverNewThinkingAi publicSans hoverOnMe">
            Dive into our solutions
          </p>
        </div>
      </div>
    
    <div id='solution'></div>
      <div
        className="container businessSection bussinessdesktop wow fadeInUp d-none d-md-block"
        data-wow-delay="0.1s"
      >
        <h3 className="text-sm text-md text-lg plexFont">
          How we could help your business
        </h3>
<br/>
<br/>

        <div className="row ">
          <div className="col-md-4 mb-4 businessSectionColumn">
            <div className="item">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  src="../assets/img/businessSection/businesssection1.png"
                  alt="Item 1"
                />
              </div>
              <h5 className="publicSans">Web3 App Development</h5>
              <p className="publicSans">
                Swift & Smart App <br />
                Deployment: Leap into the <br />
                metaverse or enrich web <br />
                experiences. Launch your <br />
                app in just a month.
              </p>
            </div>
          </div>
          <div className="col-md-4 mb-4 businessSectionColumn">
            <div className="item">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  src="../assets/img/businessSection/businesssection2.png"
                  alt="Item 2"
                />
              </div>
              <h5 className="publicSans">
                Conversational AI Customer Service{" "}
              </h5>
              <p className="publicSans">
                Your Ideal Agent, Just <br /> a Chat Away. Our AI-powered <br />
                chatbots tackle customer <br />
                service, freeing your team to <br />
                focus on core tasks.
              </p>
            </div>
          </div>
          <div className="col-md-4 mb-4 businessSectionColumn">
            <div className="item">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  src="../assets/img/businessSection/businesssection3.png"
                  alt="Item 3"
                />
              </div>
              <h5 className="publicSans">UI/UX Design House</h5>
              <p className="publicSans">
                High-impact Design, Low <br /> Cost: Our generative AI <br />{" "}
                learns your brand, delivering <br /> high-quality design without{" "}
                <br />
                the high costs. Typography
              </p>
            </div>
          </div>
        </div>
        <br/>
        <br/>
        <br/>
        <div className="row secondRow">
          <div className="col-md-4 mb-4 businessSectionColumn">
            <div className="item">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  src="../assets/img/businessSection/businesssection4.png"
                  alt="Item 4"
                />
              </div>
              <h5 className="publicSans">End-to-End Sales Suite</h5>
              <p className="publicSans">
                Swift & Smart App <br /> Deployment: Leap into the <br />{" "}
                metaverse or enrich web <br /> experiences. Launch your <br />{" "}
                app in just a month.
              </p>
            </div>
          </div>
          <div className="col-md-4 mb-4 businessSectionColumn">
            <div className="item">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  src="../assets/img/businessSection/businesssection5.png"
                  alt="Item 5"
                />
              </div>
              <h5 className="publicSans">Strategy and Transformation </h5>
              <p className="publicSans">
                Navigate Tomorrow: <br /> Leverage our advisory <br /> services
                to redefine your <br /> brand and disrupt your <br />
                market.
              </p>
            </div>
          </div>
          <div className="col-md-4 mb-4 businessSectionColumn">
            <div className="item">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  src="../assets/img/businessSection/businesssection6.png"
                  alt="Item 6"
                />
              </div>
              <h5 className="publicSans">Leadership Coaching</h5>
              <p className="publicSans">
                Become Your Best <br /> Version: Personalized AI <br /> coaching
                keeps you on track <br /> to achieving your full <br />{" "}
                potential.
              </p>
            </div>
          </div>
        </div>
        <br/>
        <br/>
        <br/>
      </div>

      <div
        className="container businessSection businessMobileSection wow fadeInUp d-block d-md-none"
        data-wow-delay="0.1s"
      >
        <h3 className="text-sm text-md text-lg plexFont">
          How we could help your business
        </h3>

        <div className="row ">
          {/* <div className="owl-carousel businessSectionCarousel"></div> */}
          <OwlCarousel
            className="businessSectionCarousel"
            items={1}
            loop={true}
            autoplay={true}
            nav={true}
          >
            <div className="item">
              <div className="col-md-4 mb-4 businessSectionColumn">
                <div>
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      src="../assets/img/businessSection/businesssection1.png"
                      alt="Item 1"
                    />
                  </div>
                  <h5 className="publicSans">Web3 App Development</h5>
                  <p className="publicSans">
                    Swift & Smart App <br />
                    Deployment: Leap into the <br />
                    metaverse or enrich web <br />
                    experiences. Launch your <br />
                    app in just a month.
                  </p>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4 mb-4 businessSectionColumn">
                <div>
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      src="../assets/img/businessSection/businesssection2.png"
                      alt="Item 2"
                    />
                  </div>
                  <h5 className="publicSans">
                    Conversational AI Customer Service{" "}
                  </h5>
                  <p className="publicSans">
                    Your Ideal Agent, Just <br /> a Chat Away. Our AI-powered{" "}
                    <br />
                    chatbots tackle customer <br />
                    service, freeing your team to <br />
                    focus on core tasks.
                  </p>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4 mb-4 businessSectionColumn">
                <div>
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      src="../assets/img/businessSection/businesssection3.png"
                      alt="Item 3"
                    />
                  </div>
                  <h5 className="publicSans">UI/UX Design House</h5>
                  <p className="publicSans">
                    High-impact Design, Low <br /> Cost: Our generative AI{" "}
                    <br /> learns your brand, delivering <br /> high-quality
                    design without <br />
                    the high costs. Typography
                  </p>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4 mb-4 businessSectionColumn">
                <div>
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      src="../assets/img/businessSection/businesssection4.png"
                      alt="Item 4"
                    />
                  </div>
                  <h5 className="publicSans">End-to-End Sales Suite</h5>
                  <p className="publicSans">
                    Swift & Smart App <br /> Deployment: Leap into the <br />{" "}
                    metaverse or enrich web <br /> experiences. Launch your{" "}
                    <br /> app in just a month.
                  </p>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4 mb-4 businessSectionColumn">
                <div>
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      src="../assets/img/businessSection/businesssection5.png"
                      alt="Item 5"
                    />
                  </div>
                  <h5 className="publicSans">Strategy and Transformation </h5>
                  <p className="publicSans">
                    Navigate Tomorrow: <br /> Leverage our advisory <br />{" "}
                    services to redefine your <br /> brand and disrupt your{" "}
                    <br />
                    market.
                  </p>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4 mb-4 businessSectionColumn">
                <div>
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      src="../assets/img/businessSection/businesssection6.png"
                      alt="Item 6"
                    />
                  </div>
                  <h5 className="publicSans">Leadership Coaching</h5>
                  <p className="publicSans">
                    Become Your Best <br /> Version: Personalized AI <br />{" "}
                    coaching keeps you on track <br /> to achieving your full{" "}
                    <br /> potential.
                  </p>
                </div>
              </div>
            </div>
          </OwlCarousel>
        </div>
      </div>

      <div id='successStory' className="container-fluid py-5 testimonialSection">
        <div className="container ">
          <OwlCarousel
            className="testimonialCarousel owl-carousel  wow fadeInUp"
            data-wow-delay="0.1s"
            items={1}
            loop={true}
            autoplay={true}
            nav={true}
          >
            <div className="testimonial-item text-center">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <img
                    className="img-fluid bg-light rounded-circle p-2 mx-auto mb-4 mainImage"
                    src="../assets/img/testimonialSection/mainImg1.png" alt=""
                  />
                </div>
                <div className="col-md-6">
                  <div
                    className="testimonial-text rounded p-4"
                    style={{ textAlign: "left" }}
                  >
                    <h3 className="plexFont">Testimonials</h3>
                    <br />

                    <img
                      className="mb-2"
                      src="../assets/img/testimonialSection/Group510.png"
                      style={{ height: "30px", width: "30px" }} alt=''
                    />
                    <p className="publicSans" style={{ color: "#000" }}>
                      Newthinking.AI didn’t just upgrade our customer service{" "}
                      <br /> they transformed it.”
                    </p>
                    <h5 className="mb-1 publicSans">Emily Nguyen</h5>
                    <p className="publicSans">Founder, InnovateRetail</p>

                    <img
                      src="../assets/img/testimonialSection/Image1.png"
                      alt="Small"
                      className="img-fluid mt-2"
                      style={{ width: "100px", height: "50px" }}
                    />
                  </div>
                </div>
              </div>
            </div>
            {/* <div className="testimonial-item text-center">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <img
                    className="img-fluid bg-light rounded-circle p-2 mx-auto mb-4 mainImage"
                    src="../assets/img/testimonialSection/mainImg1.png" alt=''
                  />
                </div>
                <div className="col-md-6">
                  <div
                    className="testimonial-text rounded p-4"
                    style={{ textAlign: "left" }}
                  >
                    <h3 className="plexFont">Testimonials</h3>
                    <br />

                    <img
                      className="mb-2"
                      src="../assets/img/testimonialSection/Group510.png"
                      style={{ height: "30px", width: "30px" }} alt=''
                    />
                    <p className="publicSans" style={{ color: "#000" }}>
                      Newthinking.AI didn’t just upgrade our customer service{" "}
                      <br /> they transformed it.”
                    </p>
                    <h5 className="mb-1 publicSans">Emily Nguyen</h5>
                    <p className="publicSans">Founder, InnovateRetail</p>

                    <img
                      src="../assets/img/testimonialSection/Image1.png"
                      alt="Small"
                      className="img-fluid mt-2"
                      style={{ width: "100px", height: "50px" }}
                    />
                  </div>
                </div>
              </div>
            </div> */}

            {/* <div className="testimonial-item text-center">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <img
                    className="img-fluid bg-light rounded-circle p-2 mx-auto mb-4 mainImage"
                    src="../assets/img/testimonialSection/mainImg1.png" alt=''
                  />
                </div>
                <div className="col-md-6">
                  <div
                    className="testimonial-text rounded p-4"
                    style={{ textAlign: "left" }}
                  >
                    <h3 className="plexFont">Testimonials</h3>
                    <br />

                    <img
                      className="mb-2"
                      src="../assets/img/testimonialSection/Group510.png"
                      style={{ height: "30px", width: "30px" }} alt=''
                    />
                    <p className="publicSans" style={{ color: "#000" }}>
                      Newthinking.AI didn’t just upgrade our customer service{" "}
                      <br /> they transformed it.”
                    </p>
                    <h5 className="mb-1 publicSans">Emily Nguyen</h5>
                    <p className="publicSans">Founder, InnovateRetail</p>

                    <img
                      src="../assets/img/testimonialSection/Image1.png"
                      alt="Small"
                      className="img-fluid mt-2"
                      style={{ width: "100px", height: "50px" }}
                    />
                  </div>
                </div>
              </div>
            </div> */}
          </OwlCarousel>
        </div>
      </div>

      <div className="container-fluid bg-primary overflow-hidden  px-lg-0 whyWeCareSection wow fadeInUp d-none d-md-block" data-wow-delay="0.1s" >
        <div className="container feature px-lg-0">
          <div className="row g-0 mx-lg-0">
            <div
              className="col-lg-6 feature-text wow fadeIn"
              data-wow-delay="0.1s"
            >
              <div className="p-lg-4">
                <br/>
                <h1 className="text-white mb-4 plexFont whyWeCareSectionH1">Why we care</h1>
                <div className="whyWeCareSectionPTag">
                <p className="text-white mb-4 pb-2 publicSans">
                  In today’s digital age, the transition into the AI era is
                  paramount for businesses seeking to elevate customer
                  experiences and achieve unparalleled growth. AI not only meets
                  the modern consumer’s demand for instant, tailored
                  interactions but also enhances human talent, automating tasks
                  and deriving insights faster than ever before. By harnessing
                  AI’s predictive power, businesses can proactively navigate
                  market shifts, breaking traditional growth barriers and
                  tapping into new opportunities seamlessly.
                </p>
                <p className="text-white mb-4 pb-2 publicSans">
                  As AI systems continuously refine and evolve, they ensure that
                  businesses remain at the cutting edge, optimizing resources
                  and driving responsible success. The future belongs to those
                  who embrace AI, positioning their ventures for a trajectory of
                  sustained excellence and innovation.
                </p>
                </div>
              </div>
            </div>
            <div
              className="col-lg-6 pe-lg-0 wow fadeIn"
              data-wow-delay="0.5s"
              style={{ minHeight: "400px" }}
            >
              <div className="position-relative h-100">
                <img
                  className="position-absolute img-fluid w-100 h-100"
                  src="../assets/img/whyWeCareSection/facial-recognition-c.png"
                  style={{ objectFit: "cover" }}
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container whyWeCareSection whyWeCareMobileSection d-block d-md-none">
        <div className="row">
          <div className="col-md-6 whyWeCareMobileSectionFirstColumn">
            <img
              className="img-fluid w-100 h-100"
              src="../assets/img/whyWeCareSection/facial-recognition-c.png"
              style={{ objectFit: "cover" }}
              alt=""
            />
          </div>
          <div className="col-md-6 whyWeCareMobileSectionSecondColumn">
            <h1 className="text-white mb-4 plexFont">Why we care</h1>
            <p className="text-white mb-4 pb-2 publicSans">
              In today’s digital age, the transition into the AI era is
              paramount for businesses seeking to elevate customer experiences
              and achieve unparalleled growth. AI not only meets the modern
              consumer’s demand for instant, tailored interactions but also
              enhances human talent, automating tasks and deriving insights
              faster than ever before. By harnessing AI’s predictive power,
              businesses can proactively navigate market shifts, breaking
              traditional growth barriers and tapping into new opportunities
              seamlessly.
            </p>
            <p className="text-white mb-4 pb-2 publicSans">
              As AI systems continuously refine and evolve, they ensure that
              businesses remain at the cutting edge, optimizing resources and
              driving responsible success. The future belongs to those who
              embrace AI, positioning their ventures for a trajectory of
              sustained excellence and innovation.
            </p>
          </div>
        </div>
      </div>

      <div
        className="container teamSection teamdesktop wow fadeInUp py-5 d-none d-md-block"
        data-wow-delay="0.1s"
      >
        <h3 className="text-sm text-md text-lg plexFont">Meet the Team</h3>

        <div className="row">
          <div className="col-md-4">
            <div className="team-member">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  className="teammemberImg"
                  src="../assets/img/teamSection/team1.png"
                  alt="Team Member 1"
                />
              </div>
              <h4 className="publicSans">Donald Lal</h4>
              <p className="publicSans">Co-Founder-CEO</p>
              <div className="social-icons d-flex justify-content-center">
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/facebook.png" />{" "}
                </Link>
                <Link to="https://www.linkedin.com/in/donald-lal-509537ba/">
                  <img alt='' src="../assets/img/teamSection/linkdin.png" />{" "}
                </Link>
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/twitter.png" />{" "}
                </Link>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="team-member">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  className="teammemberImg"
                  src="../assets/img/teamSection/team2.png"
                  alt="Team Member 2"
                />
              </div>
              <h4 className="publicSans">Jonathan Bailey</h4>
              <p className="publicSans">Co-Founder-CCO</p>
              <div className="social-icons d-flex justify-content-center">
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/facebook.png" />{" "}
                </Link>
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/linkdin.png" />{" "}
                </Link>
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/twitter.png" />{" "}
                </Link>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="team-member">
              <div className="mainImageBox d-flex  justify-content-center align-items-center">
                <img
                  className="teammemberImg"
                  src="../assets/img/teamSection/team3.png"
                  alt="Team Member 3"
                />
              </div>
              <h4 className="publicSans">Pradeep Sharma</h4>
              <p className="publicSans">Chief Architect</p>
              <div className="social-icons d-flex justify-content-center">
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/facebook.png" />{" "}
                </Link>
                <Link to="https://www.linkedin.com/in/pradeep-sharma-945717189/">
                  <img alt='' src="../assets/img/teamSection/linkdin.png" />{" "}
                </Link>
                <Link to="#">
                  <img alt='' src="../assets/img/teamSection/twitter.png" />{" "}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="container teamSection teamMobileSection wow fadeInUp py-5 d-block d-md-none"
        data-wow-delay="0.1s"
      >
        <h3 className="text-sm text-md text-lg plexFont">Meet the Team</h3>

        <div className="row">
          {/* <div className="owl-carousel teamSectionCarousel"></div> */}
          <OwlCarousel
            className="teamSectionCarousel"
            items={1}
            loop={true}
            autoplay={true}
            nav={true}
          >
            <div className="item">
              <div className="col-md-4">
                <div className="team-member">
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      className="teammemberImg"
                      src="../assets/img/teamSection/team1.png"
                      alt="Team Member 1"
                    />
                  </div>
                  <h4 className="publicSans">Donald Lal</h4>
                  <p className="publicSans">Co-Founder-CEO</p>
                  <div className="social-icons d-flex justify-content-center">
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/facebook.png" />{" "}
                    </Link>
                    <Link to="https://www.linkedin.com/in/donald-lal-509537ba/">
                      <img alt='' src="../assets/img/teamSection/linkdin.png" />{" "}
                    </Link>
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/twitter.png" />{" "}
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4">
                <div className="team-member">
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      className="teammemberImg"
                      src="../assets/img/teamSection/team2.png"
                      alt="Team Member 2"
                    />
                  </div>
                  <h4 className="publicSans">Jonathan Bailey</h4>
                  <p className="publicSans">Co-Founder-CCO</p>
                  <div className="social-icons d-flex  justify-content-center align-items-center">
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/facebook.png" />{" "}
                    </Link>
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/linkdin.png" />{" "}
                    </Link>
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/twitter.png" />{" "}
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="col-md-4">
                <div className="team-member">
                  <div className="mainImageBox d-flex  justify-content-center align-items-center">
                    <img
                      className="teammemberImg"
                      src="../assets/img/teamSection/team3.png"
                      alt="Team Member 3"
                    />
                  </div>
                  <h4 className="publicSans">Pradeep Sharma</h4>
                  <p className="publicSans">Chief Architect</p>
                  <div className="social-icons d-flex  justify-content-center align-items-center">
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/facebook.png" />{" "}
                    </Link>
                    <Link to="https://www.linkedin.com/in/pradeep-sharma-945717189/">
                      <img alt='' src="../assets/img/teamSection/linkdin.png" />{" "}
                    </Link>
                    <Link to="#">
                      <img alt='' src="../assets/img/teamSection/twitter.png" />{" "}
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </OwlCarousel>
        </div>
      </div>

      <div
        className="container startNewThinkingSection wow fadeInUp"
        data-wow-delay="0.1s"
      >
        <h3 className="text-sm text-md text-lg plexFont">
          Start your New Thinking
        </h3>
        <p className="text-sm text-md text-lg d-inline-block  border border-2 rounded-pill py-1 px-4 discoverNewThinkingAi publicSans hoverOnMe" variant="primary" onClick={() => setModalShow(true)}>
          Contact Us
        </p>
        <ContactModal show={modalShow} onHide={() => setModalShow(false)} />
      </div>
    </>
  );
}

export default Main;
import React, { useEffect, useState } from 'react';
// import { Link } from "react-router-dom";
// import "bootstrap/dist/js/bootstrap.bundle.min.js";
// import "bootstrap/dist/css/bootstrap.min.css";
import "./Header.css";
const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState(null);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };


 
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const sectionPositions = {
        services: document.getElementById('services').offsetTop,
        solution: document.getElementById('solution').offsetTop,
        successStory: document.getElementById('successStory').offsetTop,
      };

      let active = null;
      for (const section in sectionPositions) {
        if (sectionPositions[section] <= scrollPosition + 100) {
          active = section;
        }
      }

      setActiveSection(active);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
  
    <nav id='menu' className="navbar mainNavBar">
      <div className="container">
        <div className="logo">
        <a href="#" role="button">
          <img
            src="../assets/img/NewThinkingLogo.png" // Replace with your image path
            alt="NewThinkingLogo"
          />
          </a>
        </div>
      <button
          type="button"
          className="me-4 menu-button"
          onClick={toggleMenu}
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <ul className={`menu ${menuOpen ? "open" : ""}`}>
        <li className={`publicSans ${activeSection === 'services' ? 'active' : ''}`} ><a className='decoration' href="#services">SERVICES</a></li>
        <li className={`publicSans ${activeSection === 'solution' ? 'active' : ''}`}><a className='decoration' href="#solution">SOLUTION</a></li>
        <li className={`publicSans ${activeSection === 'successStory' ? 'active' : ''}`}><a className='decoration' href="#successStory">SUCCESS STORIES</a></li>
        </ul>
      </div>
    </nav>
  );
}

export default Header
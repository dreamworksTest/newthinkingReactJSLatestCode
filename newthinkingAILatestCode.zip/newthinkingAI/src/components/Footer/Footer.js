// import React, { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom';
import Chatbot from '../Chatbot/Chatbot';
import "./footer.css";

const Footer = () => {
  //   const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  //   const [step, setStep] = useState(0);
  
  //   const [chatHistory, setChatHistory] = useState([]);
  //   const [visitorName, setVisitorName] = useState('');
  //   const [phoneNumber, setPhoneNumber] = useState('');
  

  //   const chatWindowRef = useRef(null);

  // useEffect(() => {
  //   // Scroll to the bottom of the chat window when chatHistory changes
  //   if (chatWindowRef.current) {
  //     chatWindowRef.current.scrollTop = chatWindowRef.current.scrollHeight;
  //   }
  // }, [chatHistory]);

  //   const toggleChatbot = () => {
  //     setIsChatbotOpen(!isChatbotOpen);
  //   };
  
  //   const handleChatbotMessage = (message) => {
  //     if (step === 0) {
  //       setVisitorName(message);
  //       setChatHistory([
  //         ...chatHistory,
  //         { role: 'visitor', message: message },
  //         { role: 'chatbot', message: `Hi ${message}! What's your phone number?` },
  //       ]);
  //       setStep(step + 1);
  //     } else if (step === 1) {
  //       setPhoneNumber(message);
  //       setChatHistory([
  //         ...chatHistory,
  //         { role: 'visitor', message: message },
  //         { role: 'chatbot', message: `Thanks, ${visitorName}! How can I help you today?` },
  //       ]);
  //       setStep(step + 1);
  //     } else {
  //       setChatHistory([...chatHistory, { role: 'visitor', message: message }]);
  //       // Handle further chatbot logic based on visitor's responses
  //     }
  //   };

  return (
    <>
    <div className="container-fluid text-light footer mt-5 pt-5 wow fadeIn" style={{backgroundColor: "#53586F"}} data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="row g-5">
                <div className="col-lg-3 col-md-6">
                    <h5 className="text-light mb-4 publicSans">Contact Us: </h5>
                    <p className="publicSans">*Let’s Talk Human to Human*</p>
                    <p className="mb-2 publicSans"><i className="fa fa-envelope me-3"></i>info@newthinking.ai</p>
                    {/* <p className="mb-2 publicSans"><i className="fa fa-phone-alt me-3"></i>123-456-7890</p> */}
                    <p className="mb-2 publicSans"><i className="fa fa-map-marker-alt me-3"></i>109 general holmes drive kyeemagh 2216 Sydney NSW Australia</p>
                    
                </div>
                <div className="col-lg-3 col-md-6">
                   
                </div>
                <div className="col-lg-3 col-md-6">
                   
                </div>
                <div className="col-lg-3 col-md-6">
                  {/* <h5 className="text-light mb-4 publicSans">Frequently Asked Questions</h5> */}
                    {/* <h5 className="text-light mb-4 publicSans">Blog</h5> */}
                 
                </div>
            </div>
        </div>
     
    </div>
    <div className="container-fluid footer"style={{ backgroundColor: '#3A3E50' }}>
      <div className="copyright">
          <div className="row">
              <div className="col-md-12 text-center mb-3 mb-md-0">
                  &copy; <Link className="publicSans" style={{color: "#8C91A7"}}  to="#">Copyright © 2023 New Thinking AI, Inc. All rights reserved.</Link>
              </div>             
          </div>
        </div> 
      </div>

      <Chatbot />


       {/* <Link to="#" className="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i className="bi bi-arrow-up"></i></Link> */}
    </>
  );
}

export default Footer